﻿namespace $safeprojectname$
{
    public class MainViewModel
    {
    }
}
